@extends('auth.layout')

@section('content')
{{ $slot }}
@endsection