<?php $__env->startSection('title', 'Register Visit - Hospital Management System'); ?>
<?php $__env->startSection('page-title', 'Register Visit'); ?>
<?php $__env->startSection('page-description', 'Register a new patient visit'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-2xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <h3 class="text-lg font-semibold text-gray-800">Visit Registration</h3>
                <a href="<?php echo e(route('visits.index')); ?>" class="text-gray-600 hover:text-gray-800">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Visits
                </a>
            </div>
        </div>

        <form action="<?php echo e(route('visits.store')); ?>" method="POST" class="p-6">
            <?php echo csrf_field(); ?>
            
            <div class="space-y-6">
                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Patient *</label>
                    <select name="patient_id" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent" required>
                        <option value="">Select Patient</option>
                        <?php $__currentLoopData = $patients; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $patient): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($patient->id); ?>" <?php echo e(old('patient_id') == $patient->id ? 'selected' : ''); ?>>
                            <?php echo e($patient->name); ?> (<?php echo e($patient->patient_no); ?>)
                        </option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Visit Type *</label>
                    <select name="visit_type" class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent" required>
                        <option value="">Select Visit Type</option>
                        <option value="opd" <?php echo e(old('visit_type') == 'opd' ? 'selected' : ''); ?>>OPD (Out Patient Department)</option>
                        <option value="ipd" <?php echo e(old('visit_type') == 'ipd' ? 'selected' : ''); ?>>IPD (In Patient Department)</option>
                        <option value="emergency" <?php echo e(old('visit_type') == 'emergency' ? 'selected' : ''); ?>>Emergency</option>
                    </select>
                </div>

                <div>
                    <label class="block text-sm font-medium text-gray-700 mb-2">Visit Date & Time *</label>
                    <input type="datetime-local" name="visit_datetime" value="<?php echo e(old('visit_datetime', now()->format('Y-m-d\TH:i'))); ?>" 
                           class="w-full px-3 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-medical-blue focus:border-transparent" 
                           required>
                </div>
            </div>

            <div class="flex justify-end space-x-4 mt-8 pt-6 border-t border-gray-200">
                <a href="<?php echo e(route('visits.index')); ?>" class="px-6 py-2 border border-gray-300 text-gray-700 rounded-lg hover:bg-gray-50">
                    Cancel
                </a>
                <button type="submit" class="px-6 py-2 bg-medical-blue text-white rounded-lg hover:bg-blue-700 flex items-center">
                    <i class="fas fa-save mr-2"></i>
                    Register Visit
                </button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Qasim\Herd\saasy\resources\views/admin/visits/create.blade.php ENDPATH**/ ?>