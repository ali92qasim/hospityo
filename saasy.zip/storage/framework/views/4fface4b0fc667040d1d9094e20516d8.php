<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Hospital Management System</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css" rel="stylesheet">
    <style>
        body { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); min-height: 100vh; }
        .auth-card { background: rgba(255,255,255,0.95); backdrop-filter: blur(10px); border-radius: 15px; box-shadow: 0 15px 35px rgba(0,0,0,0.1); }
        .form-control { border-radius: 10px; border: 2px solid #e3f2fd; padding: 12px 15px; }
        .form-control:focus { border-color: #2196f3; box-shadow: 0 0 0 0.2rem rgba(33,150,243,0.25); }
        .btn-primary { background: linear-gradient(45deg, #2196f3, #21cbf3); border: none; border-radius: 10px; padding: 12px 30px; }
        .hospital-logo { color: #2196f3; font-size: 3rem; margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container-fluid d-flex align-items-center justify-content-center min-vh-100">
        <div class="col-md-4">
            <div class="auth-card p-5">
                <div class="text-center mb-4">
                    <i class="fas fa-hospital hospital-logo"></i>
                    <h3 class="text-primary fw-bold">Hospital Management</h3>
                </div>
                <?php echo e($slot); ?>

            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
<?php /**PATH C:\Users\Qasim\Herd\saasy\resources\views/layouts/guest.blade.php ENDPATH**/ ?>