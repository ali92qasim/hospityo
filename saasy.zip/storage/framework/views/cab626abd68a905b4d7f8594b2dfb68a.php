<?php $__env->startSection('title', 'Lab Order Details - Hospital Management System'); ?>
<?php $__env->startSection('page-title', 'Lab Order Details'); ?>
<?php $__env->startSection('page-description', 'View laboratory order information'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-4xl mx-auto">
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <div>
                    <h3 class="text-lg font-semibold text-gray-800"><?php echo e($labOrder->order_number); ?></h3>
                    <p class="text-sm text-gray-600"><?php echo e($labOrder->labTest->name); ?></p>
                </div>
                <div class="flex items-center space-x-3">
                    <?php
                        $statusColors = [
                            'ordered' => 'bg-blue-100 text-blue-800',
                            'collected' => 'bg-yellow-100 text-yellow-800',
                            'testing' => 'bg-purple-100 text-purple-800',
                            'verified' => 'bg-orange-100 text-orange-800',
                            'reported' => 'bg-green-100 text-green-800',
                            'cancelled' => 'bg-red-100 text-red-800'
                        ];
                    ?>
                    <span class="px-3 py-1 text-sm rounded-full <?php echo e($statusColors[$labOrder->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                        <?php echo e(ucfirst(str_replace('_', ' ', $labOrder->status))); ?>

                    </span>
                    <a href="<?php echo e(route('lab-orders.index')); ?>" class="text-gray-600 hover:text-gray-800">
                        <i class="fas fa-arrow-left mr-2"></i>Back to Lab Orders
                    </a>
                </div>
            </div>
        </div>

        <div class="p-6">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8">
                <!-- Order Information -->
                <div class="space-y-6">
                    <div class="bg-blue-50 rounded-lg p-4">
                        <h4 class="font-medium text-blue-800 mb-3">Order Information</h4>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between">
                                <span class="text-blue-600">Order Number:</span>
                                <span class="font-medium"><?php echo e($labOrder->order_number); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-blue-600">Test:</span>
                                <span class="font-medium"><?php echo e($labOrder->labTest->name); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-blue-600">Category:</span>
                                <span><?php echo e(ucfirst($labOrder->labTest->category)); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-blue-600">Sample Type:</span>
                                <span><?php echo e(ucfirst($labOrder->labTest->sample_type)); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-blue-600">Priority:</span>
                                <span class="px-2 py-1 text-xs rounded-full <?php echo e($labOrder->priority === 'stat' ? 'bg-red-100 text-red-800' : ($labOrder->priority === 'urgent' ? 'bg-orange-100 text-orange-800' : 'bg-gray-100 text-gray-800')); ?>">
                                    <?php echo e(strtoupper($labOrder->priority)); ?>

                                </span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-blue-600">Price:</span>
                                <span class="font-medium">₨<?php echo e(number_format($labOrder->labTest->price, 0)); ?></span>
                            </div>
                        </div>
                    </div>

                    <div class="bg-green-50 rounded-lg p-4">
                        <h4 class="font-medium text-green-800 mb-3">Patient Information</h4>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between">
                                <span class="text-green-600">Name:</span>
                                <span class="font-medium"><?php echo e($labOrder->patient->name); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-green-600">Patient No:</span>
                                <span><?php echo e($labOrder->patient->patient_no); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-green-600">Age:</span>
                                <span><?php echo e($labOrder->patient->age); ?> years</span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-green-600">Gender:</span>
                                <span><?php echo e(ucfirst($labOrder->patient->gender)); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-green-600">Phone:</span>
                                <span><?php echo e($labOrder->patient->phone); ?></span>
                            </div>
                        </div>
                    </div>

                    <?php if($labOrder->doctor): ?>
                    <div class="bg-purple-50 rounded-lg p-4">
                        <h4 class="font-medium text-purple-800 mb-3">Ordering Doctor</h4>
                        <div class="space-y-2 text-sm">
                            <div class="flex justify-between">
                                <span class="text-purple-600">Name:</span>
                                <span class="font-medium">Dr. <?php echo e($labOrder->doctor->name); ?></span>
                            </div>
                            <div class="flex justify-between">
                                <span class="text-purple-600">Specialization:</span>
                                <span><?php echo e($labOrder->doctor->specialization); ?></span>
                            </div>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>

                <!-- Timeline & Actions -->
                <div class="space-y-6">
                    <div class="bg-gray-50 rounded-lg p-4">
                        <h4 class="font-medium text-gray-800 mb-3">Timeline</h4>
                        <div class="space-y-3">
                            <div class="flex items-center text-sm">
                                <div class="w-3 h-3 bg-blue-500 rounded-full mr-3"></div>
                                <div>
                                    <span class="font-medium">Ordered</span>
                                    <div class="text-gray-500"><?php echo e($labOrder->ordered_at->format('M d, Y h:i A')); ?></div>
                                </div>
                            </div>
                            
                            <?php if($labOrder->sample_collected_at): ?>
                            <div class="flex items-center text-sm">
                                <div class="w-3 h-3 bg-yellow-500 rounded-full mr-3"></div>
                                <div>
                                    <span class="font-medium">Sample Collected</span>
                                    <div class="text-gray-500"><?php echo e($labOrder->sample_collected_at->format('M d, Y h:i A')); ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if($labOrder->sample_received_at): ?>
                            <div class="flex items-center text-sm">
                                <div class="w-3 h-3 bg-purple-500 rounded-full mr-3"></div>
                                <div>
                                    <span class="font-medium">Sample Received</span>
                                    <div class="text-gray-500"><?php echo e($labOrder->sample_received_at->format('M d, Y h:i A')); ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                            
                            <?php if($labOrder->completed_at): ?>
                            <div class="flex items-center text-sm">
                                <div class="w-3 h-3 bg-green-500 rounded-full mr-3"></div>
                                <div>
                                    <span class="font-medium">Completed</span>
                                    <div class="text-gray-500"><?php echo e($labOrder->completed_at->format('M d, Y h:i A')); ?></div>
                                </div>
                            </div>
                            <?php endif; ?>
                        </div>
                    </div>

                    <?php if($labOrder->clinical_notes): ?>
                    <div class="bg-yellow-50 rounded-lg p-4">
                        <h4 class="font-medium text-yellow-800 mb-2">Clinical Notes</h4>
                        <p class="text-sm text-yellow-700"><?php echo e($labOrder->clinical_notes); ?></p>
                    </div>
                    <?php endif; ?>

                    <?php if($labOrder->labTest->instructions): ?>
                    <div class="bg-indigo-50 rounded-lg p-4">
                        <h4 class="font-medium text-indigo-800 mb-2">Test Instructions</h4>
                        <p class="text-sm text-indigo-700"><?php echo e($labOrder->labTest->instructions); ?></p>
                    </div>
                    <?php endif; ?>

                    <!-- Action Buttons -->
                    <div class="space-y-3">
                        <?php if($labOrder->status === 'ordered'): ?>
                            <form action="<?php echo e(route('lab-orders.collect-sample', $labOrder)); ?>" method="POST" class="mb-3">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="w-full bg-yellow-600 text-white px-4 py-2 rounded-lg hover:bg-yellow-700">
                                    <i class="fas fa-vial mr-2"></i>Mark Sample Collected
                                </button>
                            </form>
                        <?php endif; ?>

                        <?php if($labOrder->status === 'collected'): ?>
                            <form action="<?php echo e(route('lab-orders.receive-sample', $labOrder)); ?>" method="POST" class="mb-3">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="w-full bg-purple-600 text-white px-4 py-2 rounded-lg hover:bg-purple-700">
                                    <i class="fas fa-check mr-2"></i>Mark Sample Received
                                </button>
                            </form>
                        <?php endif; ?>

                        <?php if($labOrder->result): ?>
                            <a href="<?php echo e(route('lab-results.show', $labOrder->result)); ?>" class="block w-full bg-green-600 text-white px-4 py-2 rounded-lg hover:bg-green-700 text-center">
                                <i class="fas fa-chart-line mr-2"></i>View Results
                            </a>
                        <?php endif; ?>

                        <a href="<?php echo e(route('lab-orders.edit', $labOrder)); ?>" class="block w-full bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-center">
                            <i class="fas fa-edit mr-2"></i>Edit Order
                        </a>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Qasim\Herd\saasy\resources\views/admin/lab/orders/show.blade.php ENDPATH**/ ?>