## Laravel Herd

- The application is served by Laravel Herd and will be available at: ___SINGLE_BACKTICK___https?://[kebab-case-project-dir].test___SINGLE_BACKTICK___. Use the ___SINGLE_BACKTICK___get-absolute-url___SINGLE_BACKTICK___ tool to generate URLs for the user to ensure valid URLs.
- You must not run any commands to make the site available via HTTP(S). It is always available through Laravel Herd.
<?php /**PATH C:\Users\Qasim\Herd\saasy\storage\framework\views/656985ff246fb76e3e889f59ef67510c.blade.php ENDPATH**/ ?>