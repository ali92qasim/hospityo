## Tailwind CSS 3

- Always use Tailwind CSS v3; verify you're using only classes supported by this version.
<?php /**PATH C:\Users\Qasim\Herd\saasy\storage\framework\views/4dbaf6902186cd24524b73612afecc09.blade.php ENDPATH**/ ?>