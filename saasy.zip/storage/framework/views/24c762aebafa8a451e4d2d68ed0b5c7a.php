<?php $__env->startSection('title', 'Patient History - Hospital Management System'); ?>
<?php $__env->startSection('page-title', 'Patient History'); ?>
<?php $__env->startSection('page-description', 'Complete medical history'); ?>

<?php $__env->startSection('content'); ?>
<div class="max-w-7xl mx-auto space-y-6">
    <!-- Patient Header -->
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6 border-b border-gray-200">
            <div class="flex items-center justify-between">
                <div class="flex items-center">
                    <div class="w-16 h-16 bg-medical-blue rounded-full flex items-center justify-center mr-4">
                        <i class="fas fa-user text-white text-2xl"></i>
                    </div>
                    <div>
                        <h3 class="text-xl font-semibold text-gray-800"><?php echo e($patient->name); ?></h3>
                        <p class="text-sm text-gray-600"><?php echo e($patient->patient_no); ?> • <?php echo e(ucfirst($patient->gender)); ?>, <?php echo e($patient->age); ?> years</p>
                        <p class="text-sm text-gray-500"><?php echo e($patient->phone); ?></p>
                    </div>
                </div>
                <a href="<?php echo e(route('patients.index')); ?>" class="text-gray-600 hover:text-gray-800">
                    <i class="fas fa-arrow-left mr-2"></i>Back to Patients
                </a>
            </div>
        </div>
        
        <!-- Summary Stats -->
        <div class="p-6">
            <div class="grid grid-cols-1 md:grid-cols-4 gap-4">
                <div class="bg-blue-50 rounded-lg p-4">
                    <div class="flex items-center">
                        <i class="fas fa-clipboard-list text-blue-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-blue-600">Total Visits</p>
                            <p class="text-2xl font-semibold text-blue-800"><?php echo e($visits->count()); ?></p>
                        </div>
                    </div>
                </div>
                <div class="bg-green-50 rounded-lg p-4">
                    <div class="flex items-center">
                        <i class="fas fa-prescription text-green-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-green-600">Prescriptions</p>
                            <p class="text-2xl font-semibold text-green-800"><?php echo e($prescriptions->count()); ?></p>
                        </div>
                    </div>
                </div>
                <div class="bg-purple-50 rounded-lg p-4">
                    <div class="flex items-center">
                        <i class="fas fa-flask text-purple-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-purple-600">Lab Tests</p>
                            <p class="text-2xl font-semibold text-purple-800"><?php echo e($labOrders->count()); ?></p>
                        </div>
                    </div>
                </div>
                <div class="bg-orange-50 rounded-lg p-4">
                    <div class="flex items-center">
                        <i class="fas fa-bed text-orange-600 text-xl mr-3"></i>
                        <div>
                            <p class="text-sm text-orange-600">Admissions</p>
                            <p class="text-2xl font-semibold text-orange-800"><?php echo e($admissions->count()); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Latest Visit Details -->
    <?php if($latestVisit): ?>
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6 border-b border-gray-200">
            <h4 class="text-lg font-semibold text-gray-800">Latest Visit Details</h4>
            <p class="text-sm text-gray-600"><?php echo e($latestVisit->visit_datetime->format('M d, Y h:i A')); ?></p>
        </div>
        <div class="p-6">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-6">
                <!-- Visit Information -->
                <div class="space-y-4">
                    <div class="bg-blue-50 rounded-lg p-4">
                        <h5 class="font-medium text-blue-800 mb-2">Visit Information</h5>
                        <div class="space-y-2 text-sm">
                            <div><span class="text-blue-600">Visit No:</span> <?php echo e($latestVisit->visit_no); ?></div>
                            <div><span class="text-blue-600">Type:</span> <?php echo e(strtoupper($latestVisit->visit_type)); ?></div>
                            <div><span class="text-blue-600">Status:</span> 
                                <?php
                                    $statusColors = [
                                        'registered' => 'bg-blue-100 text-blue-800',
                                        'vitals_recorded' => 'bg-green-100 text-green-800',
                                        'with_doctor' => 'bg-purple-100 text-purple-800',
                                        'completed' => 'bg-gray-100 text-gray-800',
                                        'admitted' => 'bg-purple-100 text-purple-800',
                                        'discharged' => 'bg-orange-100 text-orange-800'
                                    ];
                                ?>
                                <span class="px-2 py-1 text-xs rounded-full <?php echo e($statusColors[$latestVisit->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $latestVisit->status))); ?>

                                </span>
                            </div>
                            <?php if($latestVisit->doctor): ?>
                                <div><span class="text-blue-600">Doctor:</span> Dr. <?php echo e($latestVisit->doctor->name); ?></div>
                                <div><span class="text-blue-600">Specialization:</span> <?php echo e($latestVisit->doctor->specialization); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    
                    <?php if($latestVisit->vitalSigns): ?>
                    <div class="bg-green-50 rounded-lg p-4">
                        <h5 class="font-medium text-green-800 mb-2">Vital Signs</h5>
                        <div class="grid grid-cols-2 gap-2 text-sm">
                            <?php if($latestVisit->vitalSigns->blood_pressure): ?>
                                <div><span class="text-green-600">BP:</span> <?php echo e($latestVisit->vitalSigns->blood_pressure); ?></div>
                            <?php endif; ?>
                            <?php if($latestVisit->vitalSigns->temperature): ?>
                                <div><span class="text-green-600">Temp:</span> <?php echo e($latestVisit->vitalSigns->temperature); ?>°F</div>
                            <?php endif; ?>
                            <?php if($latestVisit->vitalSigns->pulse_rate): ?>
                                <div><span class="text-green-600">Pulse:</span> <?php echo e($latestVisit->vitalSigns->pulse_rate); ?> bpm</div>
                            <?php endif; ?>
                            <?php if($latestVisit->vitalSigns->respiratory_rate): ?>
                                <div><span class="text-green-600">Resp:</span> <?php echo e($latestVisit->vitalSigns->respiratory_rate); ?></div>
                            <?php endif; ?>
                            <?php if($latestVisit->vitalSigns->weight): ?>
                                <div><span class="text-green-600">Weight:</span> <?php echo e($latestVisit->vitalSigns->weight); ?> kg</div>
                            <?php endif; ?>
                            <?php if($latestVisit->vitalSigns->height): ?>
                                <div><span class="text-green-600">Height:</span> <?php echo e($latestVisit->vitalSigns->height); ?> cm</div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
                
                <!-- Consultation Details -->
                <div class="space-y-4">
                    <?php if($latestVisit->consultation): ?>
                    <div class="bg-purple-50 rounded-lg p-4">
                        <h5 class="font-medium text-purple-800 mb-2">Consultation</h5>
                        <div class="space-y-2 text-sm">
                            <?php if($latestVisit->consultation->presenting_complaints): ?>
                                <div><span class="text-purple-600">Complaints:</span> <?php echo e($latestVisit->consultation->presenting_complaints); ?></div>
                            <?php endif; ?>
                            <?php if($latestVisit->consultation->examination): ?>
                                <div><span class="text-purple-600">Examination:</span> <?php echo e($latestVisit->consultation->examination); ?></div>
                            <?php endif; ?>
                            <?php if($latestVisit->consultation->provisional_diagnosis): ?>
                                <div><span class="text-purple-600">Diagnosis:</span> <?php echo e($latestVisit->consultation->provisional_diagnosis); ?></div>
                            <?php endif; ?>
                            <?php if($latestVisit->consultation->treatment): ?>
                                <div><span class="text-purple-600">Treatment:</span> <?php echo e($latestVisit->consultation->treatment); ?></div>
                            <?php endif; ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if($latestVisit->prescriptions->count() > 0): ?>
                    <div class="bg-yellow-50 rounded-lg p-4">
                        <h5 class="font-medium text-yellow-800 mb-2">Prescriptions</h5>
                        <div class="space-y-2">
                            <?php $__currentLoopData = $latestVisit->prescriptions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prescription): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="text-sm">
                                    <div class="font-medium text-yellow-700">Prescription #<?php echo e($prescription->id); ?></div>
                                    <?php $__currentLoopData = $prescription->items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <div class="text-yellow-600 ml-2">
                                            • <?php echo e($item->medicine->name); ?> - <?php echo e($item->quantity); ?> <?php echo e($item->medicine->unit); ?> (<?php echo e($item->dosage); ?>)
                                        </div>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                    
                    <?php if($latestVisit->labOrders->count() > 0): ?>
                    <div class="bg-indigo-50 rounded-lg p-4">
                        <h5 class="font-medium text-indigo-800 mb-2">Lab Tests</h5>
                        <div class="space-y-1">
                            <?php $__currentLoopData = $latestVisit->labOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $labOrder): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="text-sm text-indigo-600">
                                    • <?php echo e($labOrder->labTest->name); ?> 
                                    <span class="text-xs">(<?php echo e(ucfirst($labOrder->status)); ?>)</span>
                                </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </div>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
            
            <div class="mt-4 pt-4 border-t border-gray-200">
                <a href="<?php echo e(route('visits.workflow', $latestVisit)); ?>" class="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700 text-sm">
                    <i class="fas fa-eye mr-2"></i>View Full Visit Details
                </a>
            </div>
        </div>
    </div>
    <?php else: ?>
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6 text-center">
            <i class="fas fa-clipboard-list text-4xl text-gray-300 mb-4"></i>
            <p class="text-gray-500">No visits found for this patient</p>
        </div>
    </div>
    <?php endif; ?>

    <!-- Recent Visits -->
    <?php if($visits->count() > 0): ?>
    <div class="bg-white rounded-lg shadow-sm">
        <div class="p-6 border-b border-gray-200">
            <h4 class="text-lg font-semibold text-gray-800">Recent Visits</h4>
        </div>
        <div class="overflow-x-auto">
            <table class="w-full">
                <thead class="bg-gray-50">
                    <tr>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Visit</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Doctor</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Diagnosis</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                        <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
                    </tr>
                </thead>
                <tbody class="divide-y divide-gray-200">
                    <?php $__currentLoopData = $visits->take(5); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $visit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td class="px-6 py-4">
                                <div class="text-sm font-medium text-gray-900"><?php echo e($visit->visit_no); ?></div>
                                <div class="text-xs text-gray-500"><?php echo e($visit->visit_datetime->format('M d, Y h:i A')); ?></div>
                                <div class="text-xs text-gray-400"><?php echo e(strtoupper($visit->visit_type)); ?></div>
                            </td>
                            <td class="px-6 py-4">
                                <?php if($visit->doctor): ?>
                                    <div class="text-sm text-gray-900">Dr. <?php echo e($visit->doctor->name); ?></div>
                                    <div class="text-xs text-gray-500"><?php echo e($visit->doctor->specialization); ?></div>
                                <?php else: ?>
                                    <span class="text-sm text-gray-400">Not assigned</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4">
                                <?php if($visit->consultation && $visit->consultation->provisional_diagnosis): ?>
                                    <div class="text-sm text-gray-900"><?php echo e(Str::limit($visit->consultation->provisional_diagnosis, 50)); ?></div>
                                <?php else: ?>
                                    <span class="text-sm text-gray-400">No diagnosis</span>
                                <?php endif; ?>
                            </td>
                            <td class="px-6 py-4">
                                <?php
                                    $statusColors = [
                                        'registered' => 'bg-blue-100 text-blue-800',
                                        'vitals_recorded' => 'bg-green-100 text-green-800',
                                        'with_doctor' => 'bg-purple-100 text-purple-800',
                                        'completed' => 'bg-gray-100 text-gray-800',
                                        'admitted' => 'bg-purple-100 text-purple-800',
                                        'discharged' => 'bg-orange-100 text-orange-800'
                                    ];
                                ?>
                                <span class="px-2 py-1 text-xs rounded-full <?php echo e($statusColors[$visit->status] ?? 'bg-gray-100 text-gray-800'); ?>">
                                    <?php echo e(ucfirst(str_replace('_', ' ', $visit->status))); ?>

                                </span>
                            </td>
                            <td class="px-6 py-4">
                                <a href="<?php echo e(route('visits.workflow', $visit)); ?>" class="text-medical-blue hover:text-blue-700 text-sm">
                                    <i class="fas fa-eye mr-1"></i>View
                                </a>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
    <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Qasim\Herd\saasy\resources\views/admin/patients/history.blade.php ENDPATH**/ ?>