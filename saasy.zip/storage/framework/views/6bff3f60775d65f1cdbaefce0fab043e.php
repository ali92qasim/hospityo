<?php $__env->startSection('title', 'Purchase Orders - Hospital Management System'); ?>
<?php $__env->startSection('page-title', 'Purchase Orders'); ?>
<?php $__env->startSection('page-description', 'Manage medicine purchase orders'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <div class="flex space-x-4">
        <select onchange="filterOrders()" id="status-filter" class="px-3 py-2 border border-gray-300 rounded-lg">
            <option value="">All Status</option>
            <option value="pending" <?php echo e(request('status') == 'pending' ? 'selected' : ''); ?>>Pending</option>
            <option value="approved" <?php echo e(request('status') == 'approved' ? 'selected' : ''); ?>>Approved</option>
            <option value="received" <?php echo e(request('status') == 'received' ? 'selected' : ''); ?>>Received</option>
            <option value="cancelled" <?php echo e(request('status') == 'cancelled' ? 'selected' : ''); ?>>Cancelled</option>
        </select>
        
        <select onchange="filterOrders()" id="supplier-filter" class="px-3 py-2 border border-gray-300 rounded-lg">
            <option value="">All Suppliers</option>
            <?php $__currentLoopData = $suppliers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $supplier): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($supplier->id); ?>" <?php echo e(request('supplier_id') == $supplier->id ? 'selected' : ''); ?>>
                    <?php echo e($supplier->name); ?>

                </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
    </div>
    
    <a href="<?php echo e(route('purchases.create')); ?>" class="bg-medical-blue text-white px-4 py-2 rounded-lg hover:bg-blue-700">
        <i class="fas fa-plus mr-2"></i>New Purchase Order
    </a>
</div>

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">PO Number</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Supplier</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order Date</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Total Amount</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $orders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm font-medium text-gray-900"><?php echo e($order->po_number); ?></div>
                        <div class="text-xs text-gray-500"><?php echo e($order->user->name); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($order->supplier->name); ?></div>
                        <div class="text-xs text-gray-500"><?php echo e($order->supplier->contact_person); ?></div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div class="text-sm text-gray-900"><?php echo e($order->order_date->format('M d, Y')); ?></div>
                        <?php if($order->expected_delivery): ?>
                            <div class="text-xs text-gray-500">Expected: <?php echo e($order->expected_delivery->format('M d, Y')); ?></div>
                        <?php endif; ?>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                        ₨<?php echo e(number_format($order->total_amount, 2)); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <?php
                            $statusColors = [
                                'pending' => 'bg-yellow-100 text-yellow-800',
                                'approved' => 'bg-blue-100 text-blue-800',
                                'received' => 'bg-green-100 text-green-800',
                                'cancelled' => 'bg-red-100 text-red-800'
                            ];
                        ?>
                        <span class="px-2 py-1 text-xs rounded-full <?php echo e($statusColors[$order->status]); ?>">
                            <?php echo e(ucfirst($order->status)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                        <a href="<?php echo e(route('purchases.show', $order)); ?>" class="text-blue-600 hover:text-blue-800 mr-3">
                            <i class="fas fa-eye"></i>
                        </a>
                        
                        <?php if($order->status === 'pending'): ?>
                            <form action="<?php echo e(route('purchases.approve', $order)); ?>" method="POST" class="inline mr-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-green-600 hover:text-green-800" title="Approve">
                                    <i class="fas fa-check"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if($order->status === 'approved'): ?>
                            <form action="<?php echo e(route('purchases.receive', $order)); ?>" method="POST" class="inline mr-2">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-purple-600 hover:text-purple-800" title="Receive">
                                    <i class="fas fa-truck"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                        
                        <?php if(in_array($order->status, ['pending', 'approved'])): ?>
                            <form action="<?php echo e(route('purchases.cancel', $order)); ?>" method="POST" class="inline" onsubmit="return confirm('Cancel this order?')">
                                <?php echo csrf_field(); ?>
                                <button type="submit" class="text-red-600 hover:text-red-800" title="Cancel">
                                    <i class="fas fa-times"></i>
                                </button>
                            </form>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="6" class="px-6 py-4 text-center text-gray-500">No purchase orders found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($orders->links()); ?>


<script>
function filterOrders() {
    const status = document.getElementById('status-filter').value;
    const supplier = document.getElementById('supplier-filter').value;
    const url = new URL(window.location);
    
    if (status) url.searchParams.set('status', status);
    else url.searchParams.delete('status');
    
    if (supplier) url.searchParams.set('supplier_id', supplier);
    else url.searchParams.delete('supplier_id');
    
    window.location = url;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Qasim\Herd\saasy\resources\views/admin/purchases/index.blade.php ENDPATH**/ ?>