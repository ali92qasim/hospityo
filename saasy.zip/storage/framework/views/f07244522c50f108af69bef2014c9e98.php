<?php $__env->startSection('title', 'Lab Results - Laboratory Information System'); ?>
<?php $__env->startSection('page-title', 'Lab Results'); ?>
<?php $__env->startSection('page-description', 'Manage laboratory test results'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <div class="flex space-x-4">
        <select onchange="filterResults()" id="status-filter" class="px-3 py-2 border border-gray-300 rounded-lg">
            <option value="">All Status</option>
            <option value="preliminary">Preliminary</option>
            <option value="final">Final</option>
            <option value="corrected">Corrected</option>
        </select>
    </div>
</div>

<!-- Pending Orders Section -->
<?php if($pendingOrders->count() > 0): ?>
<div class="bg-yellow-50 border border-yellow-200 rounded-lg p-4 mb-6">
    <h4 class="text-lg font-medium text-yellow-800 mb-3">Pending Test Results</h4>
    <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        <?php $__currentLoopData = $pendingOrders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="bg-white border border-yellow-300 rounded-lg p-3">
                <div class="flex justify-between items-start mb-2">
                    <div>
                        <p class="font-medium text-gray-800"><?php echo e($order->labTest->name); ?></p>
                        <p class="text-sm text-gray-600"><?php echo e($order->patient->name); ?></p>
                        <p class="text-xs text-gray-500"><?php echo e($order->order_number); ?></p>
                    </div>
                    <span class="px-2 py-1 text-xs rounded-full bg-orange-100 text-orange-800">
                        <?php echo e(ucfirst($order->status)); ?>

                    </span>
                </div>
                <a href="<?php echo e(route('lab-orders.results.create', $order)); ?>" class="block w-full bg-medical-blue text-white text-center px-3 py-2 rounded text-sm hover:bg-blue-700">
                    <i class="fas fa-plus mr-1"></i>Add Result
                </a>
            </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>
<?php endif; ?>

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Order #</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Patient</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Test</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Technician</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Tested</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $result): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr>
                    <td class="px-6 py-4 whitespace-nowrap font-medium"><?php echo e($result->labOrder->order_number); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($result->labOrder->patient->name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($result->labOrder->labTest->name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 py-1 text-xs rounded-full <?php echo e($result->status === 'final' ? 'bg-green-100 text-green-800' : 'bg-yellow-100 text-yellow-800'); ?>">
                            <?php echo e(ucfirst($result->status)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($result->technician->name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500"><?php echo e($result->tested_at->format('M d, Y H:i')); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                        <a href="<?php echo e(route('lab-results.show', $result)); ?>" class="text-blue-600 hover:text-blue-800 mr-3">
                            <i class="fas fa-eye"></i>
                        </a>
                        <a href="<?php echo e(route('lab-results.edit', $result)); ?>" class="text-yellow-600 hover:text-yellow-800 mr-3">
                            <i class="fas fa-edit"></i>
                        </a>
                        <?php if($result->status === 'preliminary'): ?>
                            <button onclick="verifyResult(<?php echo e($result->id); ?>)" class="text-green-600 hover:text-green-800 mr-3">
                                <i class="fas fa-check-circle"></i>
                            </button>
                        <?php endif; ?>
                        <a href="<?php echo e(route('lab-results.report', $result)); ?>" class="text-purple-600 hover:text-purple-800" target="_blank">
                            <i class="fas fa-print"></i>
                        </a>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="px-6 py-4 text-center text-gray-500">No lab results found</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($results->links()); ?>


<script>
function filterResults() {
    const status = document.getElementById('status-filter').value;
    const url = new URL(window.location);
    
    if (status) url.searchParams.set('status', status);
    else url.searchParams.delete('status');
    
    window.location = url;
}

function verifyResult(resultId) {
    if (confirm('Verify and finalize this result?')) {
        fetch(`/lab-results/${resultId}/verify`, {
            method: 'POST',
            headers: {
                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]').content
            }
        }).then(() => location.reload());
    }
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Qasim\Herd\saasy\resources\views/admin/lab/results/index.blade.php ENDPATH**/ ?>