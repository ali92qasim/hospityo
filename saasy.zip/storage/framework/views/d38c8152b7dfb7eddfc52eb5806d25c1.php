<?php $__env->startSection('title', 'Lab Workbench - Laboratory Information System'); ?>
<?php $__env->startSection('page-title', 'Lab Workbench'); ?>
<?php $__env->startSection('page-description', 'Enter and verify test results'); ?>

<?php $__env->startSection('content'); ?>
<div class="flex justify-between items-center mb-6">
    <div class="flex space-x-4">
        <select onchange="filterSamples()" id="priority-filter" class="px-3 py-2 border border-gray-300 rounded-lg">
            <option value="">All Priority</option>
            <option value="stat">STAT</option>
            <option value="urgent">Urgent</option>
            <option value="routine">Routine</option>
        </select>
    </div>
</div>

<div class="bg-white rounded-lg shadow-sm overflow-hidden">
    <table class="min-w-full divide-y divide-gray-200">
        <thead class="bg-gray-50">
            <tr>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Sample ID</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Patient</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Test</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Priority</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Status</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Collected</th>
                <th class="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">Actions</th>
            </tr>
        </thead>
        <tbody class="divide-y divide-gray-200">
            <?php $__empty_1 = true; $__currentLoopData = $pendingSamples; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                <tr class="<?php echo e($order->priority === 'stat' ? 'bg-red-50' : ''); ?>">
                    <td class="px-6 py-4 whitespace-nowrap font-mono text-sm"><?php echo e($order->sample->sample_id ?? $order->order_number); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <div>
                            <div class="font-medium"><?php echo e($order->patient->name); ?></div>
                            <div class="text-sm text-gray-500"><?php echo e($order->patient->age); ?>y <?php echo e($order->patient->gender); ?></div>
                        </div>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap"><?php echo e($order->labTest->name); ?></td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 py-1 text-xs rounded-full <?php echo e($order->priority === 'stat' ? 'bg-red-100 text-red-800' : ($order->priority === 'urgent' ? 'bg-yellow-100 text-yellow-800' : 'bg-green-100 text-green-800')); ?>">
                            <?php echo e(strtoupper($order->priority)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap">
                        <span class="px-2 py-1 text-xs rounded-full <?php echo e($order->status === 'testing' ? 'bg-blue-100 text-blue-800' : 'bg-gray-100 text-gray-800'); ?>">
                            <?php echo e(ucfirst($order->status)); ?>

                        </span>
                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                        <?php echo e($order->sample_collected_at?->format('M d, H:i') ?? 'N/A'); ?>

                    </td>
                    <td class="px-6 py-4 whitespace-nowrap text-sm">
                        <?php if($order->status === 'collected'): ?>
                            <a href="<?php echo e(route('lab-workbench.enter-results', $order)); ?>" class="text-blue-600 hover:text-blue-800">
                                <i class="fas fa-edit mr-1"></i>Enter Results
                            </a>
                        <?php elseif($order->status === 'testing'): ?>
                            <a href="<?php echo e(route('lab-workbench.enter-results', $order)); ?>" class="text-blue-600 hover:text-blue-800 mr-3">
                                <i class="fas fa-edit mr-1"></i>Continue
                            </a>
                        <?php endif; ?>
                        
                        <?php if($order->status === 'verified'): ?>
                            <a href="<?php echo e(route('lab-workbench.verify-results', $order)); ?>" class="text-green-600 hover:text-green-800">
                                <i class="fas fa-check-circle mr-1"></i>Verify
                            </a>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                <tr>
                    <td colspan="7" class="px-6 py-4 text-center text-gray-500">No pending samples</td>
                </tr>
            <?php endif; ?>
        </tbody>
    </table>
</div>

<?php echo e($pendingSamples->links()); ?>


<script>
function filterSamples() {
    const priority = document.getElementById('priority-filter').value;
    const url = new URL(window.location);
    
    if (priority) url.searchParams.set('priority', priority);
    else url.searchParams.delete('priority');
    
    window.location = url;
}
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layout', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Qasim\Herd\saasy\resources\views/admin/lab/workbench/index.blade.php ENDPATH**/ ?>